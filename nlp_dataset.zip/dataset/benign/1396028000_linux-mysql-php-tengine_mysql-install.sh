apt-get install mysql-server -y
