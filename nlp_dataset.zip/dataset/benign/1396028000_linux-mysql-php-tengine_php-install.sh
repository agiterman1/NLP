apt-get install php5-cgi php5-fpm php5-gd php5-mysql php5-curl php5-mcrypt php5-common php-apc -y
