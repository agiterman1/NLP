#!/bin/bash


if test $# -eq 0
then
    echo "인자가 부족합니다."
    exit 1
fi

