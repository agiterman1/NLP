#!/bin/bash

for fluit in apple oragnge banana; do
    echo ">> $fluit"
done

for file in ?44?.sh; do
    echo ">> $file"
done
