#!/bin/bash




grep -i "$1" <<=


10.10.79.110 lmp-imp3   imp3
10.10.79.144 lmp-imp4   imp4
10.10.79.145 lmp-imp5   imp5
10.10.79.146 lmp-imp6   imp6
10.10.79.147 lmp-imp7   imp7
10.10.40.102 lmp-stage1
10.10.79.27 lmp-board-web1      lmp-board-web1.daum.net     lmp-board-web1.biz.daum.net
10.10.79.28 lmp-board-web2      lmp-board-web2.daum.net     lmp-board-web2.biz.daum.net
10.10.79.40 lmp-board-search1
10.10.79.49 lmp-board-search2
211.32.117.145 place.local.daum.net
10.11.250.31 lmp-dvapi1
10.11.250.32 lmp-dvapi2
211.32.117.22   dti.daumcorp.com
10.255.255.61   emsdbp
10.255.255.63   emsdbs
10.10.40.42 admon1
10.98.98.30 lmp-boardtest1       lmp-board-test1.biz.daum.net
10.98.98.31 lmp-boardtest2       lmp-board-test2.biz.daum.net
10.10.40.167 lmp-boardtest3
10.10.40.168 lmp-file1 lmp-dvlog

=
