#!/bin/bash

echo "$0 PID= $$"

