#!/bin/bash


echo 3. $cheese
cheese=swiss

echo 4. $cheese
