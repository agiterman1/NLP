#当你的机器在内网的时候，可以通过这个命令查看外网的IP
curl ifconfig.me
#http://coolshell.cn/articles/8619.html
#http://blog.jobbole.com/30251/?utm_source=rss&utm_medium=rss&utm_campaign=%25e9%2592%2588%25e5%25af%25b9%25e5%25bc%2580%25e5%258f%2591%25e8%2580%2585%25e7%259a%2584%25e5%25ae%259e%25e7%2594%25a8%25e5%2591%25bd%25e4%25bb%25a4%25e8%25a1%258c%25e5%25b7%25a5%25e5%2585%25b7


