wget https://liquorix.net/install-liquorix.sh
bash install-liquorix.sh