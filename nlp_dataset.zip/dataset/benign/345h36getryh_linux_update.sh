apt update
apt upgrade
apt full-upgrade
apt-get update
apt-get upgrade
apt-get full-upgrade