#!/bin/sh

unset PATH

ECHO=/bin/echo

${ECHO} Hello World!
