brew install lua-language-server checkmake luacheck
pip install djlint
go install github.com/mrtazz/checkmake/cmd/checkmake@latest
