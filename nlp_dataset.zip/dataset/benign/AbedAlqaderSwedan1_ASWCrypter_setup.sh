mkdir output
chmod 777 ASWCrypter.sh
