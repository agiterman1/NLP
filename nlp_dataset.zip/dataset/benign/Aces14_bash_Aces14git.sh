git config --list;
git config --global user.username  Aces14;
git config --global user.name  Aces14;
git config --global user.user Aces14;
git config --global user.email javieracevedo460@yahoo.com;
git config --list;
