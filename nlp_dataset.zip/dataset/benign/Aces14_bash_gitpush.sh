#!/bin/bash
git add -A;
git commit -m "AA";
git push;
