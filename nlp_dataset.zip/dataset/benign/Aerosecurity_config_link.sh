#!/bin/sh

d=~/config
cd $d

for i in `ls -A -I link.sh -I .gitignore -I .git`
do
  cd ~
  rm -rf $i
  ln -s $d/$i
  cd $d
done
