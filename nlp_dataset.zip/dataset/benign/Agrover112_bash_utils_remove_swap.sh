git status | grep -e '\.sw[a-z]$' | xargs rm 
