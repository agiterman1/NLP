#!/bin/bash

cp -rv ~/Documents/Auth0CustomApps ~/Documents/Auth0CustomAppsBackup

echo ">>>>>>>>>>>>>>>
BACKUP COMPLETE!!!
<<<<<<<<<<<<<<<"