#!/bin/bash

cp -rv ~/Documents/CustomApps ~/Documents/CustomAppsBackup

echo ">>>>>>>>>>>>>>>
BACKUP COMPLETE!!!
<<<<<<<<<<<<<<<"