#!/bin/bash

ttab eval "cd ~/Documents/LDAP
ssh -i "ubuntu-ldap-migrated.pem" ubuntu@ec2-3-14-196-38.us-east-2.compute.amazonaws.com"