#!/bin/bash

cp -rv ~/Documents/bashScripts ~/Documents/scriptsBackup

echo ">>>>>>>>>>>>>>>
BACKUP COMPLETE!!!
<<<<<<<<<<<<<<<"
