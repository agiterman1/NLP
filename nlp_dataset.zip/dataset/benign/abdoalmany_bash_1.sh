
echo "Please enter your name:"
read name
echo "Hello $name !"
