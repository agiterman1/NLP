#!/bin/bash

sort  /etc/passwd > sortedfile.txt

