2
4
1
8
0
2

sort -nr 11.sh  >sortedargs.txt
