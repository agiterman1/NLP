#!/bin/bash
echo $USER

