#!/bin/bash
cat /etc/passwd
