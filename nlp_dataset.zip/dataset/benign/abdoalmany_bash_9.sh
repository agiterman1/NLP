#!/bin/bash

sort -n -t: +2 /etc/passwd > sortedfilen.txt
