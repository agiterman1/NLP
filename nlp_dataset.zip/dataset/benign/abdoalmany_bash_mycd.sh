#!/bin/bash
echo "enter the path"
read where_to_go 
cd $where_to_go
