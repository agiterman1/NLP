#!/bin/bash
cp {s1.sh,s2.sh} 2
echo "files copied"

