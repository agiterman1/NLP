#!/bin/bash
echo "enter the path"
read file
ls $file


