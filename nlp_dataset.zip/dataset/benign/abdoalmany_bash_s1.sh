#!/bin/bash
x=5

touch s2.sh
chmod +x s2.sh

sh ./s2.sh
