#!/bin/bash
. ./s1.sh


echo "the var from s1 = $x"
