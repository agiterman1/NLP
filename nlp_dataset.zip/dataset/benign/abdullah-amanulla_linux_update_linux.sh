#!/bin/bash

yum clean all
yum update -y
echo "OS updated"
