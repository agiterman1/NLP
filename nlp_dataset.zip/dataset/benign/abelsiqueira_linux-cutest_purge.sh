rm -rf *.bashrc *.d *.f *.so archdefs cutest mastsif sifdecode bin lib man test.log GEN.SPC gsl*
