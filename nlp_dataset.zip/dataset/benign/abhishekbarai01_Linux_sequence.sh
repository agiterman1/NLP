#!/bin/bash -x
echo ''$(( RANDOM % 10 ))''
