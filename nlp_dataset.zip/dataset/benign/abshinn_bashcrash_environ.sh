#!/usr/bin/env bash
# example bash script

echo "current working directory"
pwd

echo "environment"
printenv
