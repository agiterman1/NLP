sudo apt-get update &&
sudo apt-get install git npm unity-tweak-tool ubuntu-restricted-extras conky-all gimp tilda redshift redshift-gtk default-jre xclip guake espeak exfat-fuse exfat-utils traceroute ttf-ancient-fonts python-dev libxml2-dev libxslt-dev &&
sudo add-apt-repository ppa:noobslab/themes &&
sudo add-apt-repository ppa:webupd8team/atom &&
sudo apt-get update &&
sudo apt-get install dorian-theme simplescreenrecorder atom
