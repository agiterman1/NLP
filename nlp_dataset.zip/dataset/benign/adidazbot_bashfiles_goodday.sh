#!/bin/bash


name=$1
cohort=$2
shoesize=$3

echo "Good morning dev $name"
sleep 1
echo "your codes are very concise and easy to my $name"
sleep 2
echo "Mr $name i guess you are shoe size $shoesize"
sleep 1
echo "okay what is thw meaning of $name mr $name"
sleep 3
echo "what cohort are you in the ALXSE, let me guess $cohort 13"

