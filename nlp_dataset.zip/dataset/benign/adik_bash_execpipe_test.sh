#!/bin/bash


echo "process $@"

echo $@ >> /tmp/test

exit 0;
