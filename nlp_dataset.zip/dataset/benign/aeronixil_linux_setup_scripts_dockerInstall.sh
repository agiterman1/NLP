sudo apt update
sudo apt upgrade
sudo apt install docker.io
sudo apt install docker-compose
echo "**********************************************"
echo "done"
