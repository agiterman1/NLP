#!/bin/bash
#看环境变量
echo "user info for userid:$USER"
echo UID:$UID
echo HOME:$HOME
