#!/bin/bash
now=`date +'%y %m %d %H %M'`
echo 'now:' $now
