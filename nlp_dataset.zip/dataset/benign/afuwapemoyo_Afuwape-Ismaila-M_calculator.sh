#!/bin/bash
echo " Please Enter the first num "
read num1
echo " Please Enter the 2nd num "  
read num2 

echo The sum is   `expr $num1 + $num2` 
echo The difference is   `expr $num1 - $num2` 
echo The product is `expr  $num1 \* $num2`
echo The division is `expr  $num1 / $num2` 
echo The sum is `expr $num1 - $num2`
