#!/bin/bash
#A shell to print numbers form 100-1 using for-loop
#!/bin/sh
for (( a=100; a>=1; a--))
do
 echo $a
done

