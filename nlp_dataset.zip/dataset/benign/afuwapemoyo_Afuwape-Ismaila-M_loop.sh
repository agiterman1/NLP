#!/bin/bash
for (( a=1; a<=6; a++))
do
 echo $a
done
