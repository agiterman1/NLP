#!/bin/bash
echo "helooooo ata"
