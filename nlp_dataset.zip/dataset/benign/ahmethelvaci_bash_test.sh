#! /bin/bash

#for (( i=0; i<=5; i++ ))
#for i in 0 1 2 3 4 5
#do
# echo $i
#done

#for i in ls pwd
#do 
# echo "------$i------"
# $i
# echo
#done

for i in {1..10..2}
do
echo $i
done
