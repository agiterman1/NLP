
####################################
# gpustat - see stats about your gpu
# https://github.com/wookayin/gpustat
#
# to run:
# watch --color -n1.0 gpustat --color

pip install --user --upgrade gpustat
