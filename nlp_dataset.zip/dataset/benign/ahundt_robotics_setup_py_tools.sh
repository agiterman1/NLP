#!/bin/bash


# source: https://gist.github.com/phatblat/1713458
# Save script's current directory
DIR=$(pwd)

# /bin/bash
set -e
set -u
set -x


pip install jupyter --user --upgrade
pip install pillow --user --upgrade
pip install sklearn --user --upgrade

cd $DIR
