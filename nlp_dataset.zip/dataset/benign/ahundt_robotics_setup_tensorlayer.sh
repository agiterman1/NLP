

# https://github.com/zsdonghao/tensorlayer
pip install --user --upgrade tensorlayer