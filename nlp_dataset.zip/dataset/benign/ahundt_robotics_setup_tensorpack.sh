
# https://github.com/ppwwyyxx/tensorpack
pip install --user --upgrade tensorpack