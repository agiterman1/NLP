

# vlc media player
sudo apt-get install vlc