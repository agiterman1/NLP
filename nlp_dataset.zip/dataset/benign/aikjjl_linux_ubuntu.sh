#ubuntu20

#固化IP
