
alias dc="docker-compose"
alias dcup="docker-compose up -d"
alias dk="docker"


# proxy
alias proxy="proxychains"
alias proxyhttp="export http_proxy='http://127.0.0.1:8123' export https_proxy='http://127.0.0.1:8123'"
alias proxyhttpdelete="export http_proxy='' exprot https_proxy=''"

# systemclt
alias stc="systemclt"
alias stcs="systemclt start"
alias stcr="systemclt restart"