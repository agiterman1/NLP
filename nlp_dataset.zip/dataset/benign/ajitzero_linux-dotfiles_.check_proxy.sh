head /etc/environment
